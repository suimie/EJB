package com.ipd12;

public class Triangle implements Shape {

	public void draw() {
		System.out.println("Traingle");
	}
}
