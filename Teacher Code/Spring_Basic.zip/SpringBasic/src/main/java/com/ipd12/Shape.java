package com.ipd12;

public interface Shape {
	public void draw();
}
