package dependencyInjection;

public interface Shape {
	public void draw();
}
